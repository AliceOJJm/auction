(function(angular) {
    'use strict';
    var devise = angular.module('Devise', []);

    // @include ../401.js
    // @include ../auth.js
})(angular);
